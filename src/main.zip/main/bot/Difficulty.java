package main.bot;

public class Difficulty {
    
}
