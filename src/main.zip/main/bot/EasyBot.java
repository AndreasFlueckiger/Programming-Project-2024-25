package main.bot;

public class EasyBot {
    
}
