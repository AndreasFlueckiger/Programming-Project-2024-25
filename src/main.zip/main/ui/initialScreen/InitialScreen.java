package main.ui.initialScreen;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JPanel;

import main.saveload.SaveLoadManager;

@SuppressWarnings("serial")
public class InitialScreen extends JPanel {
    
    private JPanel containerPnl = new JPanel();
	private JButton startBtn = new JButton("New Game");
	private JButton loadBtn = new JButton("Load Game");
	private JButton exitBtn = new JButton("Exit");

	public InitialScreen() {
		setLayout(new GridBagLayout());
		setBounds(0,0,1024,768);
		setBackground(new Color(250, 250, 250));
		
		Dimension btnDimension = new Dimension(150, 50);
		
		containerPnl.setLayout(new BoxLayout(containerPnl, BoxLayout.Y_AXIS));
		containerPnl.setOpaque(false);
		
		startBtn.setBackground(new Color(0, 218, 60));
		startBtn.setForeground(new Color(0, 100, 10));
		startBtn.setFont(new Font("SansSerif", Font.BOLD, 16));
		startBtn.setPreferredSize(btnDimension);
		startBtn.setMinimumSize(btnDimension);
		startBtn.setMaximumSize(btnDimension);
		startBtn.setAlignmentX( Component.CENTER_ALIGNMENT );
		startBtn.setToolTipText("Start a new game.");
		startBtn.addActionListener(new ActionListener() { 
			public void actionPerformed(ActionEvent e) { 
				new NameForm().setVisible(true);
			} 
		} );
		
		loadBtn.setBackground(new Color(0, 203, 231));
		loadBtn.setForeground(new Color(0, 103, 131));
		loadBtn.setFont(new Font("SansSerif", Font.BOLD, 16));
		loadBtn.setPreferredSize(btnDimension);
		loadBtn.setMinimumSize(btnDimension);
		loadBtn.setMaximumSize(btnDimension);
		loadBtn.setAlignmentX( Component.CENTER_ALIGNMENT );
		loadBtn.setToolTipText("Load an archieve of a saved game.");
		loadBtn.addActionListener(new ActionListener() { 
			  public void actionPerformed(ActionEvent e) { 
				  SaveLoadManager.get().Load();
			  } 
			} );
		
		exitBtn.setBackground(new Color(223, 21, 26));
		exitBtn.setForeground(new Color(100, 5, 9));
		exitBtn.setFont(new Font("SansSerif", Font.BOLD, 16));
		exitBtn.setPreferredSize(btnDimension);
		exitBtn.setMinimumSize(btnDimension);
		exitBtn.setMaximumSize(btnDimension);
		exitBtn.setAlignmentX( Component.CENTER_ALIGNMENT );
		exitBtn.setToolTipText("Leave the game :(");
		exitBtn.addActionListener(new ActionListener() { 
			  public void actionPerformed(ActionEvent e) { 
				  System.exit(0);
			  } 
			} );
        
		containerPnl.add(startBtn);
		containerPnl.add(Box.createRigidArea(new Dimension(0, 15)));
		containerPnl.add(loadBtn);
		containerPnl.add(Box.createRigidArea(new Dimension(0, 15)));
		containerPnl.add(exitBtn);
		add(containerPnl);
	}

}
