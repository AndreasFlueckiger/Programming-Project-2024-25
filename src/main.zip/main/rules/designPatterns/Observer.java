package main.rules.designPatterns;

public interface Observer {

	//Removed public and Observable o between ()
	public void notify(Observable o);
	
}
